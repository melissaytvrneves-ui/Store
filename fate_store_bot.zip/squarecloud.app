MAIN=index.js
MEMORY=512
VERSION=recommended
DISPLAY_NAME=Fate Store Bot
DESCRIPTION=Bot de vendas e tickets da Fate Store
