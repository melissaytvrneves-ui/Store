const { 
    Client, 
    GatewayIntentBits, 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    StringSelectMenuBuilder,
    ChannelType,
    PermissionFlagsBits 
} = require('discord.js');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers
    ]
});

// TOKEN E CONFIGURAÇÕES
const TOKEN = process.env.TOKEN || "COLOCA_O_TEU_TOKEN_AQUI";
const CHAVE_PIX_TESTE = "00020126360014BR.GOV.BCB.PIX0114+550000000000052040000530398654041.005802BR5910Fate Store6009SAO PAULO62070503***6304E2CA";

client.once('ready', () => {
    console.log(`🤖 Bot ${client.user.tag} está online e pronto para vender!`);
});

// COMANDO PARA ENVIAR PAINÉIS DE REGRAS E LOJA
client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    // Comando para enviar as Regras
    if (message.content === '!regras') {
        const regrasEmbed = new EmbedBuilder()
            .setTitle('📜 Regras da Fate Store')
            .setDescription('Seja bem-vindo(a) à **Fate Store**! Por favor, leia com atenção as nossas regras antes de realizar qualquer compra:')
            .addFields(
                { name: '1. Respeito e Conduta', value: 'Trate todos os membros e suportes com educação.' },
                { name: '2. Entregas de Produtos', value: 'Após a confirmação do pagamento, aguarde o suporte enviar o seu item no canal do ticket.' },
                { name: '3. Reembolsos', value: 'Reembolsos só serão realizados caso haja algum problema comprovado do nosso lado.' },
                { name: '4. Tentativas de Fraude', value: 'Comprovantes falsos resultarão em banimento imediato e permanente.' }
            )
            .setColor('#7289DA')
            .setFooter({ text: 'Fate Store • Qualidade e Confiança' });

        await message.channel.send({ embeds: [regrasEmbed] });
    }

    // Comando para enviar o Painel da Loja & Atendimento
    if (message.content === '!painel') {
        const painelEmbed = new EmbedBuilder()
            .setTitle('🛒 Central de Atendimento & Loja - Fate Store')
            .setDescription('Selecione uma categoria abaixo no menu para abrir o seu ticket privado de compra ou suporte.')
            .setColor('#2F3136')
            .setThumbnail(client.user.displayAvatarURL())
            .setFooter({ text: 'Fate Store • Clique abaixo para iniciar' });

        const menu = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
                .setCustomId('menu_ticket')
                .setPlaceholder('Escolha o motivo do atendimento...')
                .addOptions([
                    {
                        label: 'Comprar Produtos',
                        description: 'Abre um ticket para adquirir itens e pagar via PIX',
                        value: 'ticket_comprar',
                        emoji: '💎'
                    },
                    {
                        label: 'Dúvidas / Suporte',
                        description: 'Abre um ticket de atendimento geral com a equipa',
                        value: 'ticket_suporte',
                        emoji: '❓'
                    }
                ])
        );

        await message.channel.send({ embeds: [painelEmbed], components: [menu] });
    }
});

// INTERAÇÃO COM MENUS E BOTÕES (TICKETS & LOJA)
client.on('interactionCreate', async (interaction) => {
    // 1. SELEÇÃO NO MENU DE TICKETS
    if (interaction.isStringSelectMenu()) {
        if (interaction.customId === 'menu_ticket') {
            const opcao = interaction.values[0];
            const guild = interaction.guild;
            const user = interaction.user;

            // Verificar se já existe ticket para este utilizador
            const canalExistente = guild.channels.cache.find(c => c.name === `ticket-${user.username.toLowerCase()}`);
            if (canalExistente) {
                return interaction.reply({ 
                    content: `❌ Já tens um ticket aberto em: ${canalExistente}`, 
                    ephemeral: true 
                });
            }

            // Criar canal de Ticket Privado
            const ticketChannel = await guild.channels.create({
                name: `ticket-${user.username}`,
                type: ChannelType.GuildText,
                permissionOverwrites: [
                    {
                        id: guild.id, // @everyone não vê
                        deny: [PermissionFlagsBits.ViewChannel],
                    },
                    {
                        id: user.id, // O utilizador vê
                        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.AttachFiles],
                    },
                    {
                        id: client.user.id, // O bot vê
                        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels],
                    }
                ],
            });

            await interaction.reply({ content: `✅ Ticket criado com sucesso! Acede ao canal: ${ticketChannel}`, ephemeral: true });

            if (opcao === 'ticket_comprar') {
                const lojaEmbed = new EmbedBuilder()
                    .setTitle('📦 Loja Fate Store - Escolha o seu Produto (MODO TESTE)')
                    .setDescription('Selecione o produto que deseja adquirir abaixo:')
                    .setColor('#FF0055');

                const menuProdutos = new ActionRowBuilder().addComponents(
                    new StringSelectMenuBuilder()
                        .setCustomId('selecionar_produto')
                        .setPlaceholder('Selecione o item para comprar...')
                        .addOptions([
                            {
                                label: 'VIP Bronze',
                                description: 'Preço: R$ 10,00 • Vantagens exclusivas no servidor',
                                value: 'prod_vip_bronze',
                                emoji: '🥉'
                            },
                            {
                                label: 'VIP Ouro',
                                description: 'Preço: R$ 25,00 • Acesso total e benefícios premium',
                                value: 'prod_vip_ouro',
                                emoji: '🥇'
                            },
                            {
                                label: 'Coins / Moedas do Jogo',
                                description: 'Preço: R$ 15,00 • Pacote de 1.000 moedas',
                                value: 'prod_coins',
                                emoji: '🪙'
                            }
                        ])
                );

                const btnFechar = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('fechar_ticket')
                        .setLabel('Fechar Ticket')
                        .setStyle(ButtonStyle.Danger)
                        .setEmoji('🔒')
                );

                await ticketChannel.send({ 
                    content: `Olá ${user}, bem-vindo(a) à nossa loja!`, 
                    embeds: [lojaEmbed], 
                    components: [menuProdutos, btnFechar] 
                });

            } else if (opcao === 'ticket_suporte') {
                const suporteEmbed = new EmbedBuilder()
                    .setTitle('❓ Atendimento e Suporte - Fate Store')
                    .setDescription('Descreva detalhadamente a sua dúvida ou problema. A nossa equipa irá responder em breve!')
                    .setColor('#FFA500');

                const btnFechar = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('fechar_ticket')
                        .setLabel('Fechar Ticket')
                        .setStyle(ButtonStyle.Danger)
                        .setEmoji('🔒')
                );

                await ticketChannel.send({ 
                    content: `Olá ${user}, como podemos te ajudar hoje?`, 
                    embeds: [suporteEmbed], 
                    components: [btnFechar] 
                });
            }
        }
    }

    // 2. SELEÇÃO DE PRODUTO E GERAÇÃO DE PAGAMENTO PIX
    if (interaction.isStringSelectMenu() && interaction.customId === 'selecionar_produto') {
        const produto = interaction.values[0];
        let nomeProduto = "";
        let valor = "";

        if (produto === 'prod_vip_bronze') {
            nomeProduto = "VIP Bronze";
            valor = "R$ 10,00";
        } else if (produto === 'prod_vip_ouro') {
            nomeProduto = "VIP Ouro";
            valor = "R$ 25,00";
        } else if (produto === 'prod_coins') {
            nomeProduto = "Pacote 1.000 Coins";
            valor = "R$ 15,00";
        }

        const pixEmbed = new EmbedBuilder()
            .setTitle(`💳 Pagamento PIX - ${nomeProduto}`)
            .setDescription(`**Valor:** ${valor}

Para efetuar o pagamento (Modo Teste), utilize o código **Pix Copia e Cola** abaixo:`)
            .addFields(
                { name: '🔑 Chave PIX / Copia e Cola:', value: `\`\`\`${CHAVE_PIX_TESTE}\`\`\`` },
                { name: '📌 Instruções:', value: '1. Copie o código acima.
2. Faça o pagamento no aplicativo do seu banco.
3. Envie o **comprovante em imagem** neste canal.
4. Aguarde a nossa equipa validar e entregar o seu item no jogo!' }
            )
            .setColor('#00FF7F')
            .setFooter({ text: 'Fate Store • Modo de Teste' });

        await interaction.reply({ embeds: [pixEmbed] });
    }

    // 3. FECHAR TICKET
    if (interaction.isButton() && interaction.customId === 'fechar_ticket') {
        await interaction.reply('🔒 Este ticket será encerrado em 5 segundos...');
        setTimeout(() => {
            interaction.channel.delete().catch(() => {});
        }, 5000);
    }
});

client.login(TOKEN);
